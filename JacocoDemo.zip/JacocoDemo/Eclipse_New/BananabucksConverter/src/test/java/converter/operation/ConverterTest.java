package converter.operation;

import org.junit.Test;
import static org.junit.Assert.assertEquals;


public class ConverterTest {
	Double bucks;
	@Test
	public void testAdd()
	{	

		 Converter  operations = new  Converter ();
		 
		 System.out.println("Banana Bucks amount = 100");
		 bucks=100.0;
		Double actual = operations.multiply(bucks, 1.25);
		Double expected = 125.0;
		assertEquals(expected, actual);	
	}

}
