package converter.operation;

public class Converter {
	public Double multiply(Double a, Double b)
	{
		return a*b;
	}

	public Double divide(Double a, Double b)
	{
		return a*b;
	}

}
